package com.example.distributed_rate_limiter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedRateLimiterApplicationTests {

	@Test
	void contextLoads() {
	}

}
